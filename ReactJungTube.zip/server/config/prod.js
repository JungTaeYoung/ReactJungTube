// module.exports = {
//     mongoURI:process.env.MONGO_URI
// }
module.exports = {
    mongoURI:'mongodb+srv://xodud5621:xodud2xodud2@youtubecluster.tbw6p.mongodb.net/YouTubeCluster?retryWrites=true&w=majority'
}